import UIKit

let mutiply = {
   (no1: Int, no2: Int) -> Int in
   return no1 * no2
}

let digits = mutiply(30, 2)
print(digits)
